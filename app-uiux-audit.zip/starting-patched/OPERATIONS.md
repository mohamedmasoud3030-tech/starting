# OPERATIONS.md — Environments, Deployment, Monitoring, Backup & Recovery

> Reconstructed 2026-08-17 from `vercel.json`, `supabase/config.toml`, CI
> workflow, scripts, and the operations docs. Commands below were executed in
> this workspace unless marked CI-only. No secret values appear here.

---

## 1. Environments

| Environment | Purpose | State |
| --- | --- | --- |
| Local frontend | `npm run dev` on port 3000 (host 0.0.0.0) | verified |
| Local Supabase stack | `supabase start` (needs Docker + CLI; ports: API 54321, DB 54322, Studio 54323, SMTP 54324) | CI-verified; not runnable in this workspace (no Docker) |
| Native PostgreSQL harness | `scripts/native-db/run.mjs` + concurrency scripts against any local PG | verified here on PG 18.4 (supplementary layer) |
| Production | Vercel (SPA, alias `jiwdah.vercel.app`) + Supabase project `livpmxwwxsfnaceczyth` | NOT verified from this workspace (no network egress to Vercel/Supabase) |

## 2. Environment variables (names only)

| Variable | Purpose | Where |
| --- | --- | --- |
| `VITE_SUPABASE_URL` | Supabase project URL (public, embedded in bundle) | `.env` local / Vercel env |
| `VITE_SUPABASE_ANON_KEY` | Supabase anon/publishable key (public by design) | `.env` local / Vercel env |
| `VITE_PUBLIC_DEMO_MODE` | REMOVED — the temporary public demo mode was deleted (migration 0059 + frontend removal) | — |

Rules (enforced by docs and tests): never put `service_role` or DB passwords in
`VITE_*`; the build succeeds with no env at all (login shows a "not
configured" state).

## 3. Verified command set

```bash
npm ci                 # install (Node 22 — .nvmrc/engines pinned)
npm run dev            # dev server, port 3000
npm run typecheck      # tsc --noEmit (strict)
npm run lint           # oxlint — must stay 0 warnings / 0 errors
npm test               # Vitest — 60 files / 496 tests
npm run test:watch
npm run build          # typecheck + vite build → dist/
npm run preview        # serve dist/ locally
npm run smoke:production   # SPA/PWA/SW/CSP/Vercel/chunk-size proof
npm audit --audit-level=high  # 0 vulnerabilities (one-command local check; to be re-added as a CI step once the GitHub App gains the workflows permission)
```

Database (CI-authoritative path; needs Supabase CLI + Docker):
```bash
supabase start
supabase db reset          # = npm run db:reset  (replay 56 migrations from empty)
supabase test db           # 13 pgTAP files, 559 planned assertions
supabase gen types typescript --local --schema public > src/lib/database.types.ts
```

Database (supplementary native path; plain PostgreSQL, verified here):
```bash
DB_URL=postgresql://postgres:postgres@127.0.0.1:5433/postgres \
  node scripts/native-db/run.mjs
DB_URL=… node scripts/native-db/warehouse_concurrency.mjs      # + 7 more *_concurrency.mjs
DB_URL=… npm run db:backup-restore-proof                       # local-only guard built in
```

## 4. Build & deployment contract

- `vercel.json`: SPA fallback rewrite `/(.*) → /index.html`; `no-cache` for
  `/index.html`; `immutable` for `/assets/*`; headers nosniff,
  `X-Frame-Options: DENY`, `Referrer-Policy: strict-origin-when-cross-origin`,
  Content-Security-Policy (scripts self; styles self+inline; connect self +
  `https://*.supabase.co`; object none; frame-ancestors none).
- CI builds and runs the smoke proof on every push/PR; artifacts uploaded,
  retention 1 day.
- Deploy order: apply migrations **before** the frontend (documented runbook:
  `supabase link --project-ref …` + `supabase db push`, or psql per new file).
- Frontend deploy: push to `main` (Vercel auto-deploy) or `npx vercel --prod`.
- Rollback frontend: Vercel dashboard → promote last good deployment.
- Rollback database: no schema rollback — restore from backup or write a
  forward-only repair migration (data is NOT restored by schema-only
  migrations).

## 5. Backups & restore

- Source control is **not** a data backup: migrations rebuild schema only.
- CI executes a real proof: `pg_dump → reset → pg_restore → verify fingerprint`
  on the local Supabase stack (script refuses non-local hosts).
- Production: enable Supabase managed backups on the chosen plan (docs
  recommend Pro for automated backups); verify schedule/retention in the
  dashboard — this is an owner/operator task and **cannot be verified from the
  repository**. Manual pre-deploy dumps documented in
  `docs/operations/backup-restore.md` (incl. the circular-FK warning for
  data-only dumps and the restore-into-separate-target procedure).

### 5.1 Audit-log retention (`audit_events`)

- Policy (migration 0098, defect D20): audit events older than **24 months**
  are purgeable; the purge is **per organization**, **OWNER-only**, and is
  itself recorded in the audit trail before any row is deleted.
- The purge is manual/schedulable via
  `public.purge_old_audit_events(org_id, older_than)` — the default cutoff is
  24 months; pass an explicit `older_than` to override per call.
- Suggested operational cadence: run it monthly per organization (for example
  through pg_cron or an external scheduler using an OWNER-scoped service
  token). Full removal of a closed organization's data is out of scope —
  this command never deletes rows younger than the cutoff, and there is no
  destructive org-drop path in the schema.

## 6. Monitoring & incident basics

- Available today: Supabase dashboard (DB health, auth logs), Vercel deployment
  dashboard, browser console errors (ErrorBoundary logs unhandled render
  errors), CI status as regression radar.
- Not present: application error tracking (Sentry or similar), uptime alerts,
  structured log shipping — listed as future work in the runbook.
- Incident checks, in order: CI red? → read failing job; schema drift? →
  regenerate types; migration failure? → do NOT edit applied migrations,
  forward-fix; data problem? → restore drill in
  `docs/operations/backup-restore.md`.

## 7. Owner-controlled settings & recurring dependencies

| Setting | Where | Verified? |
| --- | --- | --- |
| Auth signup on/off (`enable_signup`) | Supabase dashboard | **unverified** (external) |
| Email confirmations | Supabase dashboard (local config: disabled) | local config only |
| Managed backup schedule/retention | Supabase dashboard | **unverified** (external) |
| Vercel env vars & domain | Vercel dashboard | **unverified** (external) |
| Demo-mode deployments | build-time env per deployment | mechanism verified; live usage unverified |
| Supabase plan/quotas | dashboard | not verifiable from repo |

## 8. Troubleshooting quick reference

- **Login shows "النظام غير مهيأ":** `.env` missing/wrong `VITE_SUPABASE_URL`.
- **Type drift failure in CI:** never hand-edit `src/lib/database.types.ts`;
  regenerate from a clean local stack.
- **Native harness fails with missing pgTAP function:** update
  `scripts/native-db/pgtap_shims.sql` (functions were completed in commit
  `f1b53ac`).
- **Offline banner visible:** informational only; writes remain idempotent and
  the database is authoritative.
- **List warning "أول 1000 …":** PostgREST `max_rows` cap reached on the
  procurement lists (they keep an explicit warning by design); the main lists
  (events/customers/catalog) use real pagination (defect D21).

## 9. Production migration runbook (releases with migrations 0056–0060)

**Approved sequence — run in this exact order on the production machine:**

```bash
# 1) MANDATORY backup before any migration
pg_dump \
  --host=<SUPABASE_DB_HOST> --port=5432 --username=postgres --dbname=postgres \
  --format=custom --no-owner --no-privileges \
  --file=hospitality-pre-0056-$(date +%Y-%m-%d).dump

# 2) Apply the 61-migration chain
supabase link --project-ref livpmxwwxsfnaceczyth
supabase db push

# 3) Read-only verification (never run pgTAP or seed files on production —
#    they INSERT test data). Expect: 61 rows, both objects present, no demo role.
select count(*) from supabase_migrations.schema_migrations;                 -- 61
select to_regprocedure('public.event_readiness_batch(uuid,uuid[])') is not null; -- t
select to_regprocedure('public.transition_event_status(uuid,uuid,public.event_status,text)') is not null; -- t
select not exists (select 1 from pg_roles where rolname = 'public_demo_admin'); -- t
select count(*) from pg_policies where tablename='events' and policyname='events_update_operational'; -- 1
```

**Rollback:** database schema does not roll back — restore the `*.dump` from
step 1 (documented in `docs/operations/backup-restore.md`), or ship a forward
repair migration.

**What changes in production after this release:**
- Anonymous visitors lose ALL access (migration 0059 removed the demo role and
  its grants). The demo organization's rows, if any, remain as data.
- Events can no longer be CLOSED with equipment/consumables outstanding;
  overpayments are rejected; events in execution can be cancelled.
- `create_organization` is no longer executable from the browser.

**Immediately after migration, verify on the Vercel project:**
- `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` are set (otherwise the app
  shows the "not configured" state).
- No `VITE_PUBLIC_DEMO_MODE` variable exists (it was deleted from code).
- Managed backups are enabled with a defined retention.

## 10. Production parity checkbook (never executed from any working session)

The production Supabase project and Vercel deployment have **never been
verified against the migrations in git**. Run this before any launch claim:

```bash
# 1) Auth contexts (requires an owner-held access token + CLI login)
supabase login
supabase link --project-ref <PROJECT_REF>

# 2) Compare applied migrations vs git (expect one row per file in
#    supabase/migrations/, currently 99)
supabase migration list --local   # 99 local
supabase migration list --linked  # must equal the local list

# 3) Spot-check security-critical markers on production (read-only)
select count(*) from supabase_migrations.schema_migrations;              -- 99
select not exists (select 1 from pg_roles where rolname='public_demo_admin'); -- t
select count(*)::int from information_schema.role_routine_grants
  where grantee='anon' and routine_name='create_organization';            -- 0
select to_regprocedure('public.purge_old_audit_events(uuid,timestamptz)') is not null; -- t

# 4) Vercel: confirm the deployment's commit SHA matches the merged commit
vercel inspect <deployment-url>          # or via the Vercel dashboard
```

Never run pgTAP or seed files on production — they insert test data.
