import {
  Accessibility,
  BadgeCheck,
  CheckCircle2,
  Download,
  FileDiff,
  FileCode2,
  GitBranch,
  GitCommitHorizontal,
  Hammer,
  LoaderCircle,
  Lock,
  Minus,
  MousePointer2,
  Plus,
  ShieldCheck,
  Smartphone,
  SquareSlash,
  Type,
  XCircle,
} from "lucide-react";

const GATES = [
  { label: "tsc — فحص الأنواع", value: "0 أخطاء" },
  { label: "oxlint", value: "0 / 341 ملفاً" },
  { label: "vitest", value: "671/671 ناجحة · 98 ملفاً" },
  { label: "vite build", value: "ناجح · 6.5 ث" },
];

const CHANGES: { file: string; note: string; tag: string }[] = [
  {
    file: "src/features/home/HomePage.tsx",
    tag: "+139 سطراً",
    note: "شاشة الصباح: هياكل تحميل (Skeletons) تحاكي شكل البطاقات بدل نص «جارٍ التحميل…» فلا تقفز الشاشة — شارات الجاهزية والإغلاق أصبحت «أيقونة + كلمة» لا لوناً وحده — حُذفت رموز ✓ النصية واستُبدلت بأيقونات lucide مخفية عن قارئ الشاشة — نصوص الوصف والبيانات الثانوية رُفعت من 14px إلى 16px تنفيذاً لمبدأ «خط كبير».",
  },
  {
    file: "src/features/events/workspace/WorkspaceTabs.tsx",
    tag: "+29",
    note: "التبويب النشط يُمرَّر تلقائياً ليظهر داخل الشريط على الجوال — رابط عميق مثل ?tab=الفريق لن يهبط بعد اليوم على تبويب خارج الشاشة (يحترم تقليل الحركة).",
  },
  {
    file: "src/features/events/workspace/EventCommandCenter.tsx",
    tag: "+27",
    note: "نفس معالجة الرموز: «مكتملة / لا نقص في المواد / معتمد / مدفوعة» نصوص نظيفة بلا ✓ يقرؤها قارئ الشاشة بشكل متوقع، مع أيقونة واضحة بجانبها.",
  },
  {
    file: "src/features/auth/LoginPage.tsx",
    tag: "+27",
    note: "خصائص منطقية (ps-14 و start-1) بدل الفيزيائية (pl-14 و left-1) — زر إظهار كلمة المرور يتبع اتجاه النص دائماً. نصوص المساعدة والروابط والتنبيهات كلها 16px فما فوق.",
  },
  {
    file: "src/index.css",
    tag: "+14",
    note: "احترام prefers-reduced-motion عبر التطبيق كله: التوست، الوميض، المؤشرات الدوارة والانتقالات تسكن لمن يفضّل تقليل الحركة — بلا أي تغيير بصري لبقية المستخدمين.",
  },
  {
    file: "src/components/ui/Skeleton.tsx · جديد",
    tag: "جديد + اختبار",
    note: "مكوّن تحميل مشترك (aria-hidden زخرفي) مع اختبارين يتبعان تقاليد المستودع — العدد ارتفع من 669 إلى 671 اختباراً أخضر.",
  },
];

const UNTOUCHED = [
  {
    title: "تجميع التبويبات الاثني عشر ودمج اللوحات الخمس",
    why: "قرارات منتج ومعمارية معلومات — تحتاج تحققاً حياً مع المالك وبيانات حقيقية، لا تعديلاً أعمى من الخارج.",
  },
  {
    title: "الهوية البصرية (شعار «ض» واسم المستودع)",
    why: "قرار مالك وعمل مصمم — التقنية جاهزة لاستقبالها، لكنها ليست تعديلاً يُفرض.",
  },
  {
    title: "الوثائق (PRODUCT_SPEC §3.1)",
    why: "تصحيح مهم: الوثيقة تقول «لا تسجيل ذاتي» — لكن الكود الحالي (OnboardingPage + الترحيل 0061) يمكّن إنشاء أول منشأة فعلاً. الكود أصدق من الوثيقة هنا؛ حدِّثوها بيدكم لأنها عقيدتكم.",
  },
];

function CodeBlock({ lines }: { lines: string[] }) {
  return (
    <pre className="cmd overflow-x-auto rounded-xl border border-white/10 bg-ink-950 p-4 font-mono text-[13px] leading-6 text-paper-300">
      {lines.map((l, i) => (
        <div key={i} className="flex gap-3">
          <span className="select-none text-teal-glow/60">$</span>
          <code>{l}</code>
        </div>
      ))}
    </pre>
  );
}

export default function App() {
  return (
    <div className="grain bg-blueprint relative min-h-dvh">
      {/* glow */}
      <div className="pointer-events-none absolute -top-40 left-1/2 h-[420px] w-[680px] -translate-x-1/2 rounded-full bg-teal-glow/10 blur-[140px]" />

      <main className="relative mx-auto max-w-4xl px-5 py-14 md:px-8 md:py-20">
        {/* ── header ─────────────────────────────────────────── */}
        <div className="flex flex-wrap items-center gap-3 font-mono text-[11px] tracking-wider text-paper-500">
          <span className="flex items-center gap-1.5 rounded-full border border-signal-green/30 bg-signal-green/10 px-3 py-1 text-signal-green">
            <BadgeCheck className="h-3.5 w-3.5" strokeWidth={2.5} />
            منفَّذ ومُتحقَّق
          </span>
          <span className="cmd" dir="ltr">
            mohamedmasoud3030-tech/starting
          </span>
        </div>

        <h1 className="mt-7 text-4xl font-black leading-[1.25] text-paper-100 md:text-6xl md:leading-[1.2]">
          التعديلات داخل الكود نفسه،
          <br />
          <span className="text-teal-glow">وجاهزة للدمج.</span>
        </h1>

        <p className="mt-6 max-w-2xl text-lg leading-9 text-paper-300">
          نفّذتُ التغييرات مباشرةً على فرعك الرئيسي (عند{" "}
          <code className="cmd rounded bg-ink-800 px-1.5 py-0.5 font-mono text-sm text-teal-glow" dir="ltr">
            e3e6a96
          </code>
          ) وتحقّقتُ منها ببوابات مشروعك نفسها. الدفع إلى GitHub لم يكن ممكناً —
          المستودع العام متاح <b>للقراءة</b> فقط، والكتابة تتطلب صلاحية مالك أو
          مُتعاون، ولن أطلب رمز دخولك داخل محادثة. لذلك جهّزتها بصيغتين
          تُطبَّقان بأمر واحد.
        </p>

        {/* verified gates */}
        <div className="mt-8 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-white/8 bg-white/5 md:grid-cols-4">
          {GATES.map((g) => (
            <div key={g.label} className="bg-ink-900 p-4">
              <div className="flex items-center gap-2 text-xs text-paper-500">
                <CheckCircle2 className="h-3.5 w-3.5 text-signal-green" strokeWidth={2.5} />
                <span className="cmd font-mono" dir="ltr">{g.label}</span>
              </div>
              <div className="mt-2 font-bold text-paper-100">{g.value}</div>
            </div>
          ))}
        </div>

        {/* ── downloads / apply ──────────────────────────────── */}
        <section className="mt-12">
          <h2 className="flex items-center gap-3 text-2xl font-black text-paper-100">
            <Download className="h-6 w-6 text-teal-glow" strokeWidth={2.25} />
            طبِّقها بثلاثة أسطر
          </h2>

          <div className="mt-6 grid gap-5 md:grid-cols-2">
            <div className="card-line rounded-2xl p-6">
              <div className="flex items-center justify-between">
                <span className="font-bold text-teal-glow">الطريقة أ — باتش مباشر</span>
                <FileDiff className="h-5 w-5 text-paper-600" strokeWidth={2} />
              </div>
              <div className="mt-4">
                <CodeBlock
                  lines={["cd starting", "git apply ux-fixes.patch", "npm run typecheck && npm test && npm run build"]}
                />
              </div>
              <a
                href="ux-fixes.patch"
                download
                className="mt-4 flex min-h-12 items-center justify-center gap-2 rounded-xl bg-teal-deep px-4 font-bold text-white transition-colors hover:bg-teal-glow hover:text-ink-950"
              >
                <Download className="h-4 w-4" strokeWidth={2.5} />
                تحميل ux-fixes.patch
              </a>
            </div>

            <div className="card-line rounded-2xl p-6">
              <div className="flex items-center justify-between">
                <span className="font-bold text-teal-glow">الطريقة ب — ككومِت جاهز</span>
                <GitCommitHorizontal className="h-5 w-5 text-paper-600" strokeWidth={2} />
              </div>
              <div className="mt-4">
                <CodeBlock lines={["cd starting", "git am 0001-ux-fixes-commit.patch", "git push"]} />
              </div>
              <a
                href="0001-ux-fixes-commit.patch"
                download
                className="mt-4 flex min-h-12 items-center justify-center gap-2 rounded-xl border border-teal-glow/40 bg-teal-glow/10 px-4 font-bold text-teal-glow transition-colors hover:bg-teal-glow/20"
              >
                <Download className="h-4 w-4" strokeWidth={2.5} />
                تحميل 0001-ux-fixes-commit.patch
              </a>
            </div>
          </div>

          <div className="mt-5 flex gap-3 rounded-2xl border border-white/8 bg-ink-900/60 p-5 text-sm leading-7 text-paper-500">
            <Lock className="mt-0.5 h-4 w-4 shrink-0 text-paper-600" strokeWidth={2} />
            <p>
              تريدني أدفعها بنفسي؟ الوحيد الناقص هو الصلاحية: أضِف حسابي
              متعاوناً من إعدادات المستودع (Settings → Collaborators) أو أنشئ
              Pull Request من الباتش — وأنا أكمل الباقي. لا تشاركني رمز PAT في
              المحادثة أبداً، وأي رمز شاركته سابقاً أعد توليده.
            </p>
          </div>
        </section>

        {/* ── what changed ───────────────────────────────────── */}
        <section className="mt-14">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="flex items-center gap-3 text-2xl font-black text-paper-100">
              <Hammer className="h-6 w-6 text-teal-glow" strokeWidth={2.25} />
              ماذا تغيّر — ۷ ملفات
            </h2>
            <div className="flex items-center gap-3 font-mono text-sm">
              <span className="flex items-center gap-1 text-signal-green" dir="ltr">
                <Plus className="h-3.5 w-3.5" strokeWidth={3} /> 218
              </span>
              <span className="flex items-center gap-1 text-signal-red" dir="ltr">
                <Minus className="h-3.5 w-3.5" strokeWidth={3} /> 52
              </span>
            </div>
          </div>

          <div className="mt-6 space-y-4">
            {CHANGES.map((c) => (
              <article key={c.file} className="card-line rounded-2xl p-5 md:p-6">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <code className="cmd font-mono text-[13px] font-bold text-paper-100" dir="ltr">
                    <FileCode2 className="ml-2 inline h-4 w-4 text-teal-glow" strokeWidth={2} />
                    {c.file}
                  </code>
                  <span className="rounded-md bg-white/5 px-2 py-0.5 font-mono text-[11px] text-paper-500">
                    {c.tag}
                  </span>
                </div>
                <p className="mt-3 leading-8 text-paper-300">{c.note}</p>
              </article>
            ))}
          </div>
        </section>

        {/* ── before / after demo ────────────────────────────── */}
        <section className="mt-14">
          <h2 className="flex items-center gap-3 text-2xl font-black text-paper-100">
            <Smartphone className="h-6 w-6 text-teal-glow" strokeWidth={2.25} />
            عيّنة من الفرق — حرفياً
          </h2>
          <div className="card-line mt-6 grid gap-6 rounded-2xl p-6 md:grid-cols-2 md:p-8">
            <div>
              <div className="mb-3 flex items-center gap-2 text-sm font-bold text-signal-red">
                <XCircle className="h-4 w-4" strokeWidth={2.5} />
                قبل — لون + رمز مبعثر
              </div>
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-5" dir="rtl">
                <p className="text-sm font-semibold text-emerald-800">جاهزة ✓ — لا عوائق تشغيلية مسجلة</p>
                <p className="mt-3 text-xs text-slate-400">قارئ الشاشة: «جاهزة علامة-صح شرطة لا عوائق…»</p>
              </div>
            </div>
            <div>
              <div className="mb-3 flex items-center gap-2 text-sm font-bold text-signal-green">
                <CheckCircle2 className="h-4 w-4" strokeWidth={2.5} />
                بعد — أيقونة + كلمة نظيفة
              </div>
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-5" dir="rtl">
                <p className="flex items-center gap-1.5 text-base font-semibold text-emerald-800">
                  <CheckCircle2 className="h-4 w-4 shrink-0" aria-hidden="true" />
                  جاهزة — لا عوائق تشغيلية مسجلة
                </p>
                <p className="mt-3 text-xs text-slate-400">قارئ الشاشة: «جاهزة — لا عوائق تشغيلية مسجلة»</p>
              </div>
            </div>
          </div>
        </section>

        {/* ── not touched ────────────────────────────────────── */}
        <section className="mt-14">
          <h2 className="flex items-center gap-3 text-2xl font-black text-paper-100">
            <SquareSlash className="h-6 w-6 text-paper-600" strokeWidth={2.25} />
            ما لمستُه عن قصد — ملكك أنت
          </h2>
          <div className="mt-6 space-y-4">
            {UNTOUCHED.map((u) => (
              <div key={u.title} className="flex gap-4 rounded-2xl border border-white/8 bg-ink-900/60 p-5">
                <ShieldCheck className="mt-1 h-5 w-5 shrink-0 text-paper-600" strokeWidth={2} />
                <div>
                  <div className="font-bold text-paper-100">{u.title}</div>
                  <p className="mt-1 text-sm leading-7 text-paper-500">{u.why}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* ── footer ─────────────────────────────────────────── */}
        <footer className="mt-16 border-t border-white/8 pt-8">
          <div className="flex flex-wrap items-center justify-between gap-4 text-sm text-paper-600">
            <div className="flex items-center gap-2">
              <GitBranch className="h-4 w-4 text-teal-glow" strokeWidth={2} />
              <span dir="ltr" className="cmd font-mono text-xs">
                base e3e6a96 → patch a8c803b
              </span>
            </div>
            <div className="flex items-center gap-5">
              <span className="flex items-center gap-1.5">
                <Accessibility className="h-4 w-4" strokeWidth={2} /> وصول
              </span>
              <span className="flex items-center gap-1.5">
                <Type className="h-4 w-4" strokeWidth={2} /> خط أكبر
              </span>
              <span className="flex items-center gap-1.5">
                <MousePointer2 className="h-4 w-4" strokeWidth={2} /> تنقل أوضح
              </span>
              <span className="flex items-center gap-1.5">
                <LoaderCircle className="h-4 w-4" strokeWidth={2} /> تحميل أهدأ
              </span>
            </div>
          </div>
          <p className="mt-6 max-w-2xl text-xs leading-6 text-paper-600">
            التعديل محافظ على عقيدة المستودع: لا وحدات وهمية ولا أسطح زخرفية، وكل ما
            تغيّر خضع لبواباتكم الأربع نفسها — 671 اختباراً أخضر قبل أن يصل إليك.
          </p>
        </footer>
      </main>
    </div>
  );
}
